new fairyDustCursor({element: document.querySelector("#fairyDust")});
new ghostCursor({element: document.querySelector("#ghost")});
new springyEmojiCursor({element: document.querySelector("#springs")});
new emojiCursor({element: document.querySelector("#emoji")});
new bubbleCursor({element: document.querySelector("#bubbles")});
new snowflakeCursor({element: document.querySelector("#snowflake")});
